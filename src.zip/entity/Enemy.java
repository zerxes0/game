package entity;

public class Enemy {

}
